import random
pname = input("Enter First Name")
cname = input("Enter Computer Name")
rounds = int(input("Best of :"))
print("Lets the battle begins","\n***",pname,"***","vs","***",cname,"***","\nChoose\n1. Rock\n2. Paper\n3. Scissor")
PlayerScore = 0
ComputerScore = 0
run = True
i = 0
while run == True:
   for i in range (rounds):
      computer = random.randint(1, 3)
      choose = int(input("Enter your weapon here:"))
      if choose == 1:
          if computer == 3:
              print("Computer choose: Scissor\nYou Win! Rocks break scissor")
              playerScore = PlayerScore +1
              i += 1
              print("Player score", PlayerScore , "")
          else:
              print("Computer wins!")
              ComputerScore = ComputerScore + 1
              i += 1
              print("Player score ", PlayerScore, "\nComputer score ", ComputerScore)
      elif choose == 2:
          if computer == 1:
              print("Computer choose: Paper\nComputer Wins! Paper covers rock")
              ComputerScore = ComputerScore + 1
              i += 1
              print("Player score ",PlayerScore,"\nComputer score ", ComputerScore)
          else:
              print("You win!")
              PlayerScore = PlayerScore + 1
              i += 1
              print("Player score ", PlayerScore, "\nComputer score ",ComputerScore)
      elif choose == 3:
          if computer == 2:
              print("Computer choose: Paper \n You win! Scissor cut paper!")
              PlayerScore = PlayerScore + 1
              i += 1
              print("Player score ", PlayerScore, "\nComputer score ", ComputerScore)
          else:
              print("Computer Win!")
              ComputerScore = ComputerScore +1
              i += 1
              print("Player score ",PlayerScore,"\nComputer score ",ComputerScore)
   else:
     run = input("Do you want to play again? [Y] Yes or [N] No :")
     if run == 'Y':
        run = True
        continue
     else:
        run = False
else:
    if PlayerScore > ComputerScore:
        print("CONGRATULATION! YOU WIN !\n","Your Score :",PlayerScore,"\nComputer Score :",ComputerScore)
    else:
        print("YOU LOSE! \n",PlayerScore,"\n",ComputerScore)
